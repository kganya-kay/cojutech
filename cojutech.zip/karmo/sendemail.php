<?php
$name       = @trim(stripslashes($_POST['name'])); 
$company     = @trim(stripslashes($_POST['company'])); 
$from       = @trim(stripslashes($_POST['email']));  
$message    = @trim(stripslashes($_POST['message'])); 
$to   		= 'kganya@cojutech.co.za';

$headers   = array();
$headers[] = "MIME-Version: 1.0";
$headers[] = "Content-type: text/plain; charset=iso-8859-1";
$headers[] = "From: {$name} <{$from}>";
$headers[] = "Reply-To: <{$from}>";
$headers[] = "X-Mailer: PHP/".phpversion();

mail($to, "message from cojutech from ".$name."company ".$company, $message, $headers);
header('Location: index.html?mail sent');
die;
?>